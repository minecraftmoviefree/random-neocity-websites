
   var number = 1;
   function next () {
     number=number+1;
     if (number>9) {
       number = 1;
     }
     photo.src = "https://resumegaliullindenis.neocities.org/img/"+number+".jpg";
     caption.innerHTML = "Фото #" + number;
   }