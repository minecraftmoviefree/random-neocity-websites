var percent = 22;
   function deposit () {
     var money = document.getElementById("depositing").value;
     var term= document.getElementById('term').value;
     var days = +(term) * 365;
     var madmonq = +(money);
     let sum = [];
     sum[0]=madmonq;
     for (let i = 1; i < days; i++) 
     {
       sum[i]=sum[i-1]+(sum[0]*(percent/100)/365);
     }
     sum.forEach(e => caption.innerHTML += "<p>" + "Вклад составит:" + e + " рублей" + "</p>");
   }
   function clear(content) {
   content.innerHTML="";
   }